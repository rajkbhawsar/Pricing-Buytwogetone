﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Pricing.DataObject
{
    //this object represent database entity
    public class ItemDO
    {
        public string ItemCode {get;set;} 
        public string ItemName{get;set;}
        public int Quantity{get;set;}
        public double PricePerItem{get;set;}
        
    }
}
