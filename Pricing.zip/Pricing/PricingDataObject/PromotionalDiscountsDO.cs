﻿using Pricing.Common;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Pricing.DataObject
{
    //this object represent database entity
    public class PromotionalDiscounts
    {
        public Constants.ItemCode ItemCodetobeFree{get;set;}
        public Constants.PromotionalSchemeType schemeName {get;set;}
        public double DiscountPercentage {get;set;}
    }

    
}
