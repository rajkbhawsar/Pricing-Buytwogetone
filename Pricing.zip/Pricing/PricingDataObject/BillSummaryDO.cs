﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pricing.DataObject
{
    //this object represent database entity
    public class BillSummaryDO
    {
        //not implementing other details like cust id and date bill number
        public double TotalPricing { get; set; }
        public double TotalDiscount {get;set;}              
       
    }
}
