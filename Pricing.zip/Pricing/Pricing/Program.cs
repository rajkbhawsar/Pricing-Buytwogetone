﻿using Pricing.BusinessRules;
using Pricing.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.BusinessObject;
using Pricing.BusinessObject;

namespace Pricing
{
    class Program
    {
        static void Main(string[] args)
        {
            Pricing.BusinessRules.ShoppingCart myCart =  new BusinessRules.ShoppingCart();
            myCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.TVSamSung48Inch, Quantity = 2 });
            myCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.TVSamSung32Inch, Quantity = 2 });
            myCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.MNDellMonitor16Inch, Quantity = 3 });


            BillSummaryBO billSummaryBO =new PricingWorkflow().calculateNetAmount(myCart);
            Console.WriteLine("TotalPricing " + billSummaryBO.TotalPricing);
            Console.WriteLine("TotalDiscount " + billSummaryBO.TotalDiscount);
            Console.WriteLine("Net Payable " + billSummaryBO.NetPayable);
            Console.ReadLine();
        }
    }
}
