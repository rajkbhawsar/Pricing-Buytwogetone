﻿using Pricing.BusinessObject;
using Pricing.BusinessRules;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Pricing.Test
{
    class TestData
    {
        internal ShoppingCart TestCart;
        internal BillSummaryBO DesiredResult;
    }
}
