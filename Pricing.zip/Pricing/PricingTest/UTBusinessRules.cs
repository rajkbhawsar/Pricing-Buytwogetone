﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pricing.BusinessRules;
using Pricing.BusinessObject;
using Pricing.Common;

namespace Pricing.Test
{
    [TestClass]
    public class UTBusinessRules
    {
        #region Discounting Logic
        [TestMethod]
        public void TC_Scheme_BuyTwoGetOneFreeThreeQtyOneShouldFree()
        {
            //Arrange
            TestData testData = SampleData.BuyTwoGetOneFreeThreeQtyOneShouldFree();

            //Act
            PricingWorkflow pricingWorkflow = new PricingWorkflow();
            BillSummaryBO testResult = pricingWorkflow.calculateNetAmount(testData.TestCart);

            //Assert
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing, testResult.TotalPricing);
            Assert.AreEqual<double>(testData.DesiredResult.TotalDiscount, testResult.TotalDiscount);
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing - testData.DesiredResult.TotalDiscount, testResult.NetPayable);
        }

        [TestMethod]
        public void TC_Scheme_BuyTwoGetOneFreeFiveQtyOneShouldFree()
        {
            //Arrange
            TestData testData = SampleData.BuyTwoGetOneFreeFiveQtyOneShouldFree();

            //Act
            PricingWorkflow pricingWorkflow = new PricingWorkflow();
            BillSummaryBO testResult = pricingWorkflow.calculateNetAmount(testData.TestCart);

            //Assert
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing, testResult.TotalPricing);
            Assert.AreEqual<double>(testData.DesiredResult.TotalDiscount, testResult.TotalDiscount);
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing - testData.DesiredResult.TotalDiscount, testResult.NetPayable);
        }

        [TestMethod]
        public void TC_Scheme_BuyTwoGetOneFreeSixQtyTwoShouldFree()
        {
            //Arrange
            TestData testData = SampleData.BuyTwoGetOneFreeSixQtyTwoShouldFree();

            //Act
            PricingWorkflow pricingWorkflow = new PricingWorkflow();
            BillSummaryBO testResult = pricingWorkflow.calculateNetAmount(testData.TestCart);

            //Assert
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing, testResult.TotalPricing);
            Assert.AreEqual<double>(testData.DesiredResult.TotalDiscount, testResult.TotalDiscount);
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing - testData.DesiredResult.TotalDiscount, testResult.NetPayable);
        }

        [TestMethod]
        public void TC_Scheme_ComboOfferOneEligibleItemShouldFree()
        {
            //Arrange
            TestData testData = SampleData.ComboOfferOneEligibleItemShouldFree();

            //Act
            PricingWorkflow pricingWorkflow = new PricingWorkflow();
            BillSummaryBO testResult = pricingWorkflow.calculateNetAmount(testData.TestCart);

            //Assert
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing, testResult.TotalPricing);
            Assert.AreEqual<double>(testData.DesiredResult.TotalDiscount, testResult.TotalDiscount);
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing - testData.DesiredResult.TotalDiscount, testResult.NetPayable);
        }

        [TestMethod]
        public void TC_Scheme_ComboOfferNoFreebieSelected()
        {
            //Arrange
            TestData testData = SampleData.ComboOfferNoFreebieSelected();

            //Act
            PricingWorkflow pricingWorkflow = new PricingWorkflow();
            BillSummaryBO testResult = pricingWorkflow.calculateNetAmount(testData.TestCart);

            //Assert
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing, testResult.TotalPricing);
            Assert.AreEqual<double>(testData.DesiredResult.TotalDiscount, testResult.TotalDiscount);
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing - testData.DesiredResult.TotalDiscount, testResult.NetPayable);
        }

        [TestMethod]
        public void TC_Scheme_ComboOfferOneEligibleItemShouldFreeOutOfTwo()
        {
            //Arrange
            TestData testData = SampleData.ComboOfferOneEligibleItemShouldFreeOutOfTwo();

            //Act
            PricingWorkflow pricingWorkflow = new PricingWorkflow();
            BillSummaryBO testResult = pricingWorkflow.calculateNetAmount(testData.TestCart);

            //Assert
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing, testResult.TotalPricing);
            Assert.AreEqual<double>(testData.DesiredResult.TotalDiscount, testResult.TotalDiscount);
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing - testData.DesiredResult.TotalDiscount, testResult.NetPayable);
        }

        [TestMethod]
        public void TC_Scheme_MultipleItemsWithMultipleScheme()
        {
            //Arrange
            TestData testData = SampleData.MultipleItemsWithMultipleScheme();

            //Act
            PricingWorkflow pricingWorkflow = new PricingWorkflow();
            BillSummaryBO testResult = pricingWorkflow.calculateNetAmount(testData.TestCart);

            //Assert
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing, testResult.TotalPricing);
            Assert.AreEqual<double>(testData.DesiredResult.TotalDiscount, testResult.TotalDiscount);
            Assert.AreEqual<double>(testData.DesiredResult.TotalPricing - testData.DesiredResult.TotalDiscount, testResult.NetPayable);
        }

        #endregion Discounting Logic

        #region Exception testing
        [TestMethod]
        public void TC_Exception_MinimumQuantityException()
        {
            //Arrange
            ShoppingCart TestCart = new ShoppingCart();

            //Act
            try
            {
                TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.MNDellMonitor16Inch, Quantity = 0 });
            }
            catch (Exception ex)
            {
                //Assert
                StringAssert.Contains(ex.Message, Constants.MinimumQuantityException);
                return;
            }
            Assert.Fail("No exception was thrown");
        }

        [TestMethod]
        public void TC_Exception_FreebieItemnotSpecified()
        {
            //Arrange
            TestData testData = SampleData.FreebieItemnotSpecified();


            //Act
            try
            {
                PricingWorkflow pricingWorkflow = new PricingWorkflow();
                BillSummaryBO testResult = pricingWorkflow.calculateNetAmount(testData.TestCart);
            }
            catch (Exception ex)
            {
                //Assert
                StringAssert.Contains(ex.Message, Constants.FreebieItemnotSpecified);
                return;
            }
            Assert.Fail("No exception was thrown");
        }

        #endregion Exception testing
    }
}
