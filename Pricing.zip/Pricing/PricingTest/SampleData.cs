﻿using Pricing.BusinessObject;
using Pricing.BusinessRules;
using Pricing.Common;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Pricing.Test
{
    //Below are the schemes declared by the vendor
    //Buy two get one free
    // if customer buy two TV (TVSamSung32Inch) he can get one same item free
    // if customer buy two Monitor (MNDellMonitor16Inch) he can get one same item free
    // if customer buy two Mouse (MSFrontechMouse) he can get one same item free
    // Combination Base buy two get one free
    // if customer buy two TV (TVSamSung48Inch) he would be eligible for one free TV (TVSamSung32Inch)
    // if customer buy two Microware (MWPanasonic20LT) he would be eligible for one free Bowlset (MWBowlSet)
    // there is no discount on Microware MWIFB26LT
   
    class SampleData
    {
        #region Discounting Logic
        //Scheme : Buy two get one free
        //Item  MNDellMonitor16Inch price per item 4500
        //Total Price should be 4500*3 = 13500 and discount should be 4500
        //sample data description supply 3 quantity of buy two get one item only one item should be discounted other 2 would be chargable
        internal static TestData BuyTwoGetOneFreeThreeQtyOneShouldFree()
        {
            ShoppingCart TestCart = new ShoppingCart();
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.MNDellMonitor16Inch, Quantity = 3 });

            BillSummaryBO desiredBillSummary = new BillSummaryBO() { TotalPricing = 13500, TotalDiscount = 4500 };
            return new TestData() { TestCart = TestCart, DesiredResult = desiredBillSummary };

        }

        //Scheme : Buy two get one free
        //Item :  MNDellMonitor16Inch price per item 4500
        //Total Price should be 4500*5 = 22500 and discount should be 4500
        //sample data description: supply 5 quantity of buy two get one item only one item should be discounted other 4 would be chargable
        internal static TestData BuyTwoGetOneFreeFiveQtyOneShouldFree()
        {
            ShoppingCart TestCart = new ShoppingCart();
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.MNDellMonitor16Inch, Quantity = 5 });

            BillSummaryBO desiredBillSummary = new BillSummaryBO() { TotalPricing = 22500, TotalDiscount = 4500 };
            return new TestData() { TestCart = TestCart, DesiredResult = desiredBillSummary };

        }

        //Scheme : Buy two get one free
        //Item :  MNDellMonitor16Inch price per item 4500
        //Total Price should be 4500*6 = 27000 and discount should be 9000
        //sample data description: supply 6 quantity of buy two get one item two item should be discounted other 4 would be chargable
        internal static TestData BuyTwoGetOneFreeSixQtyTwoShouldFree()
        {
            ShoppingCart TestCart = new ShoppingCart();
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.MNDellMonitor16Inch, Quantity = 6 });

            BillSummaryBO desiredBillSummary = new BillSummaryBO() { TotalPricing = 27000, TotalDiscount = 9000 };
            return new TestData() { TestCart = TestCart, DesiredResult = desiredBillSummary };

        }

        //Scheme : combination offer Buy two TVSamSung48Inch get one TVSamSung32Inch free
        //Item : TVSamSung48Inch price per item 48000
        //Item : TVSamSung32Inch price per item 32000
        //Total Price should be 48000*2 + 32000 = 128000 and discount should be 32000 
        //sample data description supply  two quantity of combo offer and one freebie item
        internal static TestData ComboOfferOneEligibleItemShouldFree()
        {
            ShoppingCart TestCart = new ShoppingCart();
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.TVSamSung48Inch, Quantity = 2 });
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.TVSamSung32Inch, Quantity = 1 });

            BillSummaryBO desiredBillSummary = new BillSummaryBO() { TotalPricing = 128000, TotalDiscount = 32000 };
            return new TestData() { TestCart = TestCart, DesiredResult = desiredBillSummary };

        }

        //Scheme : combination offer Buy two TVSamSung48Inch get one TVSamSung32Inch free
        //Item : TVSamSung48Inch price per item 48000
        //sample data description supply  two quantity of combo offer and do not supply the eligible freebie item
        //since customer not wishing to have 32 inch tv no discount should be given
        internal static TestData ComboOfferNoFreebieSelected()
        {
            ShoppingCart TestCart = new ShoppingCart();
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.TVSamSung48Inch, Quantity = 2 });

            BillSummaryBO desiredBillSummary = new BillSummaryBO() { TotalPricing = 96000, TotalDiscount = 0 };
            return new TestData() { TestCart = TestCart, DesiredResult = desiredBillSummary };

        }

        //Scheme : combination offer Buy two TVSamSung48Inch get one TVSamSung32Inch free
        //Item : TVSamSung48Inch price per item 48000
        //Item : TVSamSung32Inch price per item 32000
        //Total Price should be 48000*2 + 32000*2 = 128000 and discount should be 32000 
        //sample data description supply  two quantity of combo offer and two freebie item
        //since only one quantity qualify for freebie discount should be 32000 only
        internal static TestData ComboOfferOneEligibleItemShouldFreeOutOfTwo()
        {
            ShoppingCart TestCart = new ShoppingCart();
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.TVSamSung48Inch, Quantity = 2 });
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.TVSamSung32Inch, Quantity = 2 });

            BillSummaryBO desiredBillSummary = new BillSummaryBO() { TotalPricing = 160000, TotalDiscount = 32000 };
            return new TestData() { TestCart = TestCart, DesiredResult = desiredBillSummary };

        }

        //Scheme : MultipleItemsWithMultipleScheme
        //Item : TVSamSung48Inch price per item 48000  : scheme : buy two get one TVSamSung32Inch free
        //Item : TVSamSung32Inch price per item 32000  : scheme : no discount
        //Item : MWIFB26LT price per item 16000  : scheme : no discount
        //Item : MNDellMonitor16Inch price per item 4500  : scheme : Buy two get one 
        //Total Price should be 48000*2 + 32000*2 +16000*2 + 4500*3 = 205500 and discount should be 32000 
        //sample data description supply  two quantity of combo offer and two freebie item
        //only one TVSamSung32Inch eligible for freebie and one MNDellMonitor16Inch (32000+4500) total discount 36500 
        internal static TestData MultipleItemsWithMultipleScheme()
        {
            ShoppingCart TestCart = new ShoppingCart();
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.TVSamSung48Inch, Quantity = 2 });
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.TVSamSung32Inch, Quantity = 2 });
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.MWIFB26LT, Quantity = 2 });
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.MNDellMonitor16Inch, Quantity = 3 });

            BillSummaryBO desiredBillSummary = new BillSummaryBO() { TotalPricing = 205500, TotalDiscount = 36500 };
            return new TestData() { TestCart = TestCart, DesiredResult = desiredBillSummary };

        }


        #endregion Discounting Logic


        #region Exception testing
        //sample data description supply 0 quantity of buy item exception should be there
        internal static TestData FreebieItemnotSpecified()
        {
            ShoppingCart TestCart = new ShoppingCart();
            TestCart.AddItemInCart(new ItemBO() { ItemCode = Constants.ItemCode.MNDellMonitor22Inch, Quantity = 2 });

            BillSummaryBO desiredBillSummary = new BillSummaryBO() { TotalPricing = 0, TotalDiscount = 0 };
            return new TestData() { TestCart = TestCart, DesiredResult = desiredBillSummary };

        }

        #endregion Exception testing
    }
}
