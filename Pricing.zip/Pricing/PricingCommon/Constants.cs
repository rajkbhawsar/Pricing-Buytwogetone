﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//this namespace will be having all the constants/Enums used in the solution any extesion classes if required.
namespace Pricing.Common
{
    
    public static class Constants
    {
        public enum PromotionalSchemeType
        {
            BuyTwoGetOne,
            ComboOffer,
            FlatDiscount,
            NoDiscount
        }

        public enum ItemCode
        {
            None,
            TVSamSung32Inch ,
            TVSamSung48Inch ,
            MWPanasonic20LT ,
            MWIFB26LT ,
            MNDellMonitor16Inch ,
            MNDellMonitor22Inch ,
            MSFrontechMouse ,
            MWBowlSet 
        }

        public const string MinimumQuantityException = "At-least one quantity should be there";
        public const string FreebieItemnotSpecified = "Freebie Item not Specified";
        public const string ItemOutofStockException = "Item out of stock";

    }
}
