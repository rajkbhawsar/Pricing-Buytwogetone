﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.DataObject;
using Pricing.Common;

namespace Pricing.BusinessRules
{
    //this is factory implementation according to scheme type it will return aproprieate calculation methode 
    class DicountSchemeFactory
    {
        internal iDiscountCalculate getDiscountScheme(Constants.PromotionalSchemeType promotionalSchemeType)
        {
            switch (promotionalSchemeType)
            {
                case Constants.PromotionalSchemeType.BuyTwoGetOne:
                    return new CalculateDiscountBuytwoGetOne();
                    
                case Constants.PromotionalSchemeType.ComboOffer:
                    return new CalculateDiscountComboOffer();
                    
                case Constants.PromotionalSchemeType.FlatDiscount:
                    return new CalculateFlatDiscount();
                    
                default:
                    return new CalculateNoDiscount();
                    
            }

        }
    }
}
