﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.DataObject;

namespace Pricing.BusinessRules
{
    //interface for loose coupling
    interface iPricing
    {
        double calculatePrice(ShoppingCart shoppingCart);
    }
}
