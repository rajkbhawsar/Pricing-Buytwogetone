﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.BusinessObject;

namespace Pricing.BusinessRules
{
    //interface for loose coupling
    interface iDiscountCalculate
    {
        double calculateDiscount(ShoppingCart shoppingCart,ItemBO item);

    }
}
