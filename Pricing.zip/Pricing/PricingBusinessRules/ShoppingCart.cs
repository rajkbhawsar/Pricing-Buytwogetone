﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.Common;
using Pricing.BusinessObject;

namespace Pricing.BusinessRules
{
    public class ShoppingCart
    {
        public List<ItemBO> Cart;
        public ShoppingCart()
        {
            Cart = new List<ItemBO>();
        }

        public List<ItemBO> AddItemInCart(ItemBO item)
        {
            try
            {
                if (item.Quantity <= 0) throw new Exception(Constants.MinimumQuantityException);

                ItemBO Existingitem = Cart.Find(itm => itm.ItemCode == item.ItemCode);
                if (Existingitem == null)
                    Cart.Add(item);
                else Existingitem.Quantity = Existingitem.Quantity + item.Quantity;
                
                return Cart;
            }
            catch (Exception ex)
            {
                //write proper error logging logic to log the exception in event viewwer/text file/ database
                throw ex;
            }
           
        }      

    }
}
