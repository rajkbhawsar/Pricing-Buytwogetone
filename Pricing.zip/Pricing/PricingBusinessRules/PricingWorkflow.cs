﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.DataObject;
using Pricing.BusinessObject;
using Pricing.Common;

namespace Pricing.BusinessRules
{
    // workflow class for entire calculation of pricing
    public class PricingWorkflow
    {
        public BillSummaryBO calculateNetAmount(ShoppingCart shoppingCart)
        {
            //since this is the entry point to business logic, data object  we should have check point for any exception
            try
            {
                checkForDiscountAndPricing(shoppingCart);
                double totalPricing = new TotalPricing().calculatePrice(shoppingCart);
                double totalDiscount = new TotalDiscount().calculatePrice(shoppingCart);

                return new BillSummaryBO() { TotalPricing = totalPricing, TotalDiscount = totalDiscount };
            }
            catch (Exception ex)
            {
                //write proper error logging logic to log the exception in event viewwer/text file/ database
                throw ex; 
            }
          
        }


        void checkForDiscountAndPricing(ShoppingCart shoppingCart)
        {
            foreach (var item in shoppingCart.Cart)
            {
                //only business can add the discount and promotional offers
                addPromotionalDiscount(item);

                //only business can define the price
                addPrice(item);
            }        

        }

        //ideally this should come from database, here we should map the DO object with BO object and get the discount scheme
        //as there is no database connection hardcoded scheme is there.
        ItemBO addPromotionalDiscount(ItemBO item)
        {
            switch (item.ItemCode)
            {
                case Constants.ItemCode.TVSamSung32Inch:
                    item.PromotionalDiscounts = new PromotionalDiscountsBO() { schemeName = Constants.PromotionalSchemeType.NoDiscount };
                    break;
                case Constants.ItemCode.TVSamSung48Inch:
                    item.PromotionalDiscounts = new PromotionalDiscountsBO() { schemeName = Constants.PromotionalSchemeType.ComboOffer, ItemCodetobeFree = Constants.ItemCode.TVSamSung32Inch };
                    break;
                case Constants.ItemCode.MWPanasonic20LT:
                    item.PromotionalDiscounts = new PromotionalDiscountsBO() { schemeName = Constants.PromotionalSchemeType.ComboOffer, ItemCodetobeFree = Constants.ItemCode.MWBowlSet };
                    break;
                case Constants.ItemCode.MWIFB26LT:
                    item.PromotionalDiscounts = new PromotionalDiscountsBO() { schemeName = Constants.PromotionalSchemeType.NoDiscount };
                    break;
                case Constants.ItemCode.MNDellMonitor16Inch:
                    item.PromotionalDiscounts = new PromotionalDiscountsBO() { schemeName = Constants.PromotionalSchemeType.BuyTwoGetOne };
                    break;
                case Constants.ItemCode.MNDellMonitor22Inch:
                    item.PromotionalDiscounts = new PromotionalDiscountsBO() { schemeName = Constants.PromotionalSchemeType.ComboOffer };
                    break;
                case Constants.ItemCode.MSFrontechMouse:
                    item.PromotionalDiscounts = new PromotionalDiscountsBO() { schemeName = Constants.PromotionalSchemeType.BuyTwoGetOne };
                    break;
                default:
                    item.PromotionalDiscounts = new PromotionalDiscountsBO() { schemeName = Constants.PromotionalSchemeType.NoDiscount };
                    break;
            }
            return item;
        }

        //ideally price should come from database here we should map the DO object with BO object and get the price since
        //there is no database connection hardcoded price is there.
        ItemBO addPrice(ItemBO item)
        {
            switch (item.ItemCode)
            {
                case Constants.ItemCode.TVSamSung32Inch:
                    item.PricePerItem = 32000;
                    break;
                case Constants.ItemCode.TVSamSung48Inch:
                    item.PricePerItem = 48000;
                    break;
                case Constants.ItemCode.MWPanasonic20LT:
                    item.PricePerItem = 12000;
                    break;
                case Constants.ItemCode.MWIFB26LT:
                    item.PricePerItem = 16000;
                    break;
                case Constants.ItemCode.MNDellMonitor16Inch:
                    item.PricePerItem = 4500;
                    break;
                case Constants.ItemCode.MNDellMonitor22Inch:
                    item.PricePerItem = 6000;
                    break;
                case Constants.ItemCode.MSFrontechMouse:
                    item.PricePerItem = 180;
                    break;
                default:
                    item.PricePerItem = 0;
                    break;
            }
            return item;
        }
    }
}
