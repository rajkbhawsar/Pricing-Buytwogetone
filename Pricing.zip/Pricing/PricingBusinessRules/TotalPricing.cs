﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Pricing.BusinessRules
{
    // class is reponcible for calculating the gross total for entire cart
    class TotalPricing:iPricing
    {
        public double calculatePrice(ShoppingCart shoppingCart)
        {
            double totalPrice = 0;
            foreach (var item in shoppingCart.Cart)
            {
                totalPrice = totalPrice + (item.Quantity * item.PricePerItem);
            }
            return totalPrice;
        }
    }
}
