﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.BusinessObject;
using Pricing.Common;

namespace Pricing.BusinessRules
{
    class CalculateDiscountComboOffer : iDiscountCalculate
    {
        public double calculateDiscount(ShoppingCart shoppingCart,ItemBO item)
        {
            double discountAmount = 0;
            //first check if there is 2 item them only go for discount calculation coz it is buy two get one
            if (item.Quantity >= 2)
            {
                //check if combo offer applied on the item and freebie not defined then throw an exception
                if (item.PromotionalDiscounts.ItemCodetobeFree == 0) throw new Exception(Constants.FreebieItemnotSpecified);

                //check if there is item which is qualifing for free in cart, if customer not wish to have freebie then retun from here
                // it can be debatable if we should throw exception from here and tell customer that he is eligible to have freebie
                if (shoppingCart.Cart.FirstOrDefault(itm => itm.ItemCode == item.PromotionalDiscounts.ItemCodetobeFree) == null) return 0;
                                               
                //check what quantity of freebie customer is eligible to get free of cost
                int eligibleQuantity = (int)item.Quantity / 2;


                if (eligibleQuantity > shoppingCart.Cart.FirstOrDefault(itm => itm.ItemCode == item.PromotionalDiscounts.ItemCodetobeFree).Quantity)
                {
                    //if eligible eligibleQuantity is greater then the quantity available in cart then take cart's quantity
                    //in short customer wish to have lasser quantity then what he is eligible for                    
                    discountAmount = discountAmount +
                        (shoppingCart.Cart.FirstOrDefault(itm => itm.ItemCode == item.PromotionalDiscounts.ItemCodetobeFree).Quantity *
                        shoppingCart.Cart.FirstOrDefault(itm => itm.ItemCode == item.PromotionalDiscounts.ItemCodetobeFree).PricePerItem);
                }
                else
                {
                    //in case customer buy more than or equal to eligible quantity of freebie we need to calculate discount on the eligible quantity only
                    discountAmount = discountAmount +
                        (eligibleQuantity * shoppingCart.Cart.FirstOrDefault(itm => itm.ItemCode == item.PromotionalDiscounts.ItemCodetobeFree).PricePerItem);
                }
            }
            return discountAmount;
        }
    }
}
