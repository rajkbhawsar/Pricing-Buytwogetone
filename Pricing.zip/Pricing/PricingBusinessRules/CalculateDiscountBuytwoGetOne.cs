﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.BusinessObject;


namespace Pricing.BusinessRules
{
    class CalculateDiscountBuytwoGetOne : iDiscountCalculate
    {
        public double calculateDiscount(ShoppingCart shoppingCart, ItemBO item)
        {
            double discountAmount = 0;

            //Go for discount calculation only if morethen two items are there
            if (item.Quantity > 2)
            {
                int FreeQnatity = (int)item.Quantity / 3;
                discountAmount = discountAmount + FreeQnatity * item.PricePerItem;
            }
            return discountAmount;
        }
    }
}
