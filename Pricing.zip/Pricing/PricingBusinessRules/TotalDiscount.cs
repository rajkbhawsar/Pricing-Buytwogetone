﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Pricing.BusinessRules
{
    // class is reponcible for calculating the discount for entire cart
   class TotalDiscount : iPricing
    {
       public double calculatePrice(ShoppingCart shoppingCart)
        {
            double totalDiscount = 0;
            foreach (var item in shoppingCart.Cart)
            {
                totalDiscount = totalDiscount +
                    (new DicountSchemeFactory().getDiscountScheme(item.PromotionalDiscounts.schemeName).calculateDiscount(shoppingCart,item));
            }
            return totalDiscount;
        }
             
    }
}
