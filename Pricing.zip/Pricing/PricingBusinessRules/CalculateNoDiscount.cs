﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.BusinessObject;

namespace Pricing.BusinessRules
{
    class CalculateNoDiscount : iDiscountCalculate
    {
        public double calculateDiscount(ShoppingCart shoppingCart, ItemBO item)
        {
            return 0;
        }
    }
    
}
