﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pricing.BusinessObject;

namespace Pricing.BusinessRules
{
    class CalculateFlatDiscount :iDiscountCalculate
    {
        //implementation not in scope kept for future requirement
        double iDiscountCalculate.calculateDiscount(ShoppingCart shoppingCart, ItemBO item)
        {
            throw new NotImplementedException();
        }
    }
}
