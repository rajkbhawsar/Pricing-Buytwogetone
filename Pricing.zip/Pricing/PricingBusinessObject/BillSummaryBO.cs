﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Pricing.BusinessObject
{
    //this object represent business object modal which need to map with data object for certain fields
    public class BillSummaryBO
    {
        //not implementing other details like cust id and date bill number
        public double TotalPricing { get; set; }
        public double TotalDiscount {get;set;}

        public double NetPayable
        {
            get
            {
                return this.TotalPricing - TotalDiscount;
            }           
        }
    }
}
