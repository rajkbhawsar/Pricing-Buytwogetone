﻿using Pricing.Common;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Pricing.BusinessObject
{
    //this class represent the business object modal which need to map with data object
    public class PromotionalDiscountsBO
    {
        public Constants.ItemCode ItemCodetobeFree{get;set;}
        public Constants.PromotionalSchemeType schemeName {get;set;}
        public double DiscountPercentage {get;set;}
    }

    
}
