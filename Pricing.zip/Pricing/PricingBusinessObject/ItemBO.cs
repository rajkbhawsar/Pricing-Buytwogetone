﻿using Pricing.Common;
using Pricing.DataObject;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Pricing.BusinessObject
{
    //this class represent the business object modal of an item which need to map with data object for certain fields
    public class ItemBO
    {
        //since right now we dont have database connectivity to ease development using enum
        public Constants.ItemCode ItemCode { get; set; }
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        
        //only business can decide what should be price that why kept internal moreover it should come from database
        public double PricePerItem { get; set; }

        //only business can decide what promotional discount can be applied that why kept internal
        public PromotionalDiscountsBO PromotionalDiscounts { get; set; }
    }
}
